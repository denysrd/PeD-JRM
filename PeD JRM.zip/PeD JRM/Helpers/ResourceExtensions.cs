﻿using Microsoft.Windows.ApplicationModel.Resources;

namespace PeD_JRM.Helpers;

public static class ResourceExtensions
{
    private static readonly ResourceLoader _resourceLoader = new();

    public static string GetLocalized(this string resourceKey) => _resourceLoader.GetString(resourceKey);
}
