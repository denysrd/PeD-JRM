﻿using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.UI.Xaml;
using PeD_JRM.Views;

namespace PeD_JRM.ViewModels;

public partial class HomeViewModel : ObservableRecipient
{
    public HomeViewModel()
    {
    }
}
