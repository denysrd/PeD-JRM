﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PeD_JRM.ViewModels;

public partial class ReceitasViewModel : ObservableRecipient
{
    public ReceitasViewModel()
    {
    }
}
