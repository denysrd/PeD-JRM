﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PeD_JRM.ViewModels;

public partial class CadastrosViewModel : ObservableRecipient
{
    public CadastrosViewModel()
    {
    }
}
