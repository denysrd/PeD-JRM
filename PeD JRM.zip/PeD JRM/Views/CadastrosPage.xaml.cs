﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PeD_JRM.ViewModels;
using Microsoft.UI.Xaml.Input;

namespace PeD_JRM.Views;

public sealed partial class CadastrosPage : Page
{
    public CadastrosViewModel ViewModel
    {
        get;
    }

    public CadastrosPage()
    {
        ViewModel = App.GetService<CadastrosViewModel>();
        InitializeComponent();
    }
    private void OnFornecedorTapped(object sender, TappedRoutedEventArgs e)
    {
       
    }

    private void OnTipoIngredienteTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnTipoFormulacaoTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnInsumosTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnFlavorizantesTapped(object sender, TappedRoutedEventArgs e)
    {
       
    }

    private void OnComponentesAromaticosTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnEmbalagensTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnFormulacaoEssenciaTapped(object sender, TappedRoutedEventArgs e)
    {
        
    }

    private void OnFormulacaoAromaTapped(object sender, TappedRoutedEventArgs e)
    {
      
    }

}
